TURHAN AKARYAKIT - CPANEL YAYIN TALIMATI

Dosyalar:
- index.html
- assets klasoru (css, js, img)

CPANEL'E YUKLEME:
1. cPanel'e girin.
2. File Manager'i acin.
3. public_html klasorune girin.
4. Eski site dosyalarinin yedegini alin.
5. Bu paketin icindeki tum dosyalari public_html icine yukleyin.
6. En onemli nokta: index.html dosyasi public_html klasorunun icinde olmali.
7. Domain turhanpetrol.com bu klasore bagliysa site hemen acilir.

TELEFON / WHATSAPP:
- Sabit Hat: 0332 755 74 34
- Cep / WhatsApp: 0533 697 05 31

KONUM LINKI:
- https://maps.app.goo.gl/qP37bb31LNHwsw4eA?g_st=ic

NOT:
Site statiktir. PHP veya veritabani gerekmez.
